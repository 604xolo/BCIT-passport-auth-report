 interface User {
  id: number;
  name: string;
  email: string;
  password: string;
   role: "user" | "admin";
  avatarUrl?: string;
  provider?: "local" | "github";
}
const database: User[] = [
  { 
    id: 1,
    name: "Jimmy Smith",
    email: "jimmy123@gmail.com",
    password: "jimmy123!" ,
    role: "admin",
    provider: "local"
  },
     {  
      id: 2,
      name: "Johnny Doe",
      email: "johnny123@gmail.com",
      password: "johnny123!", 
      role: "user",
      provider: "local"
    },
     { 
      id: 3,
      name: "Jonathan Chen",
      email: "jonathan123@gmail.com",
      password: "jonathan123!",
      role: "user",
      provider: "local"
    },

];

let nextId = 4;

const userModel = {
   all(): User[] {
    return database;
  },

  /* FIX ME (types) 😭 DONE */
  findOne: (email: string) => {
    const user = database.find((user) => user.email === email);
    if (user) {
      return user;
    }
    throw new Error(`Couldn't find user with email: ${email}`);
  },
  /* FIX ME (types) 😭 DONE */ 
  findById: (id: number):User => {
    const user = database.find((user) => user.id === id);
    if (user) {
      return user;
    }
    throw new Error(`Couldn't find user with id: ${id}`);
  },
};

function createFromGithub(data: { name: string; email?: string; avatarUrl?: string }): User {
    const newUser: User = {
      id: nextId++,
      name: data.name,
      email: data.email,
      role: "user",
      avatarUrl: data.avatarUrl,
      provider: "github"
    };
    database.push(newUser);
    return newUser;
  }

export { database, userModel, User createFromGithub};
